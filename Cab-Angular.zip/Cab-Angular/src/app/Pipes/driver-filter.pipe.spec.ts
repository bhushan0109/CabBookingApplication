import { DriverFilterPipe } from './driver-filter.pipe';

describe('DriverFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DriverFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
