import { LocationPipe } from './location.pipe';

describe('LocationPipe', () => {
  it('create an instance', () => {
    const pipe = new LocationPipe();
    expect(pipe).toBeTruthy();
  });
});
