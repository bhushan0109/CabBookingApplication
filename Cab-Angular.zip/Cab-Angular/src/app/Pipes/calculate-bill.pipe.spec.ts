import { CalculateBillPipe } from './calculate-bill.pipe';

describe('CalculateBillPipe', () => {
  it('create an instance', () => {
    const pipe = new CalculateBillPipe();
    expect(pipe).toBeTruthy();
  });
});
