export interface IAdmin {
  adminId: number;

}
