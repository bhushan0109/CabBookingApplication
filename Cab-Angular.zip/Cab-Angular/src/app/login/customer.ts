export interface ICustomer {
  customerId: number;

}
