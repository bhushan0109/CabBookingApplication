export interface IDriver {
  driverId: number;

}
