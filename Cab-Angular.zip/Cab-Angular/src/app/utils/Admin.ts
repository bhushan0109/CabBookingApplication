export class IAdmin{
  adminId: number=0;
  email: string='';
  mobileNumber: string='';
  password: string='';
  username: string='';
}
