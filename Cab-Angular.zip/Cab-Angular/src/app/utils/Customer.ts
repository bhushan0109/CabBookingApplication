export class ICustomer{
  customerId: number=0;
  email: string='';
  mobileNumber: string='';
  password: string='';
  username: string='';
}
