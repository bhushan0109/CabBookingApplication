import { ICab } from './Cab';
export class IDriver{


  driverId: number=0;
  email: string='';
  mobileNumber: string='';
  password: string='';
  username: string='';

}
