export class ICab{
  cabId:number=0;
    carType: string='';
    perKmRate: number=0;
}
