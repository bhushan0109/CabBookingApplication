export interface IUser{
  username: string,
  password: string,
  mobileNumber: string,
  email: string

}
